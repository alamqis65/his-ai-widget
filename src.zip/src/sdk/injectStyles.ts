/**
 * injectStyles.ts — AUTO-GENERATED
 *
 * CSS di-embed langsung ke dalam JS bundle.
 * Dipanggil saat his_ai_widget.init() — inject ke <head> sekali saja.
 *
 * JANGAN edit file ini manual.
 * Edit src/styles/index.css lalu jalankan: npm run build:lib
 */

const CSS = `@import url("https://fonts.googleapis.com/css2?family=DM+Sans:wght@300;400;500;600&family=DM+Mono:wght@400;500&display=swap");

/* ─── Tokens ──────────────────────────────────────────────────────────────── */
:root {
  --brand: #1a9e76;
  --brand-dark: #0f7558;
  --brand-light: #e6f7f2;

  --bg: #ffffff;
  --bg-2: #f8fafc;
  --bg-3: #f1f5f9;
  --border: #e2e8f0;
  --border-2: #cbd5e1;

  --text-1: #0f172a;
  --text-2: #475569;
  --text-3: #94a3b8;

  --radius-sm: 6px;
  --radius-md: 10px;
  --radius-lg: 14px;
  --radius-xl: 18px;
  --radius-full: 9999px;

  --shadow-sm: 0 1px 3px rgb(0 0 0/0.08);
  --shadow-md: 0 4px 16px rgb(0 0 0/0.1);
  --shadow-lg: 0 12px 40px rgb(0 0 0/0.14);
  --shadow-widget: 0 24px 64px rgb(0 0 0/0.18), 0 0 0 1px rgb(0 0 0/0.06);

  --font: "DM Sans", system-ui, sans-serif;
  --mono: "DM Mono", monospace;

  --nav-h: 64px;
  --header-h: 56px;
  --widget-w: 380px;
  --widget-h: 620px;
}

/* ─── Reset ───────────────────────────────────────────────────────────────── */
*,
*::before,
*::after {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
}
html,
body {
  height: 100%;
  font-family: var(--font);
  background: #f0f4f8;
  color: var(--text-1);
  -webkit-font-smoothing: antialiased;
}
button {
  font-family: var(--font);
  cursor: pointer;
}
input,
textarea {
  font-family: var(--font);
}
#app {
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* ─── Widget Root ─────────────────────────────────────────────────────────── */
.widget-root {
  display: flex;
  flex-direction: column;
  width: var(--widget-w);
  height: var(--widget-h);
  background: var(--bg);
  border-radius: var(--radius-xl);
  overflow: hidden;
  box-shadow: var(--shadow-widget);
  position: relative;
}

/* ─── Header ──────────────────────────────────────────────────────────────── */
.widget-header {
  height: var(--header-h);
  min-height: var(--header-h);
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 16px;
  background: var(--bg);
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}

.widget-header-left {
  display: flex;
  align-items: center;
  gap: 10px;
}

.widget-avatar {
  width: 36px;
  height: 36px;
  border-radius: var(--radius-md);
  background: linear-gradient(135deg, var(--brand), var(--brand-dark));
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  flex-shrink: 0;
}

.widget-header-title {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-1);
  line-height: 1.2;
}

.widget-header-sub {
  font-size: 11px;
  color: var(--text-3);
  display: flex;
  align-items: center;
  gap: 4px;
  margin-top: 1px;
}

.widget-status-dot {
  width: 6px;
  height: 6px;
  background: #22c55e;
  border-radius: 50%;
  animation: pulse-dot 2s ease-in-out infinite;
}

@keyframes pulse-dot {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.4;
  }
}

.widget-header-close {
  width: 28px;
  height: 28px;
  border: none;
  background: transparent;
  color: var(--text-3);
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 120ms ease;
}
.widget-header-close:hover {
  background: var(--bg-3);
  color: var(--text-2);
}

/* ─── Content ─────────────────────────────────────────────────────────────── */
.widget-content {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  min-height: 0;
}

/* ─── Bottom Nav ──────────────────────────────────────────────────────────── */
.widget-nav {
  height: var(--nav-h);
  min-height: var(--nav-h);
  display: flex;
  align-items: stretch;
  border-top: 1px solid var(--border);
  background: var(--bg);
  flex-shrink: 0;
}

.widget-nav-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 3px;
  border: none;
  background: transparent;
  color: var(--text-3);
  padding: 8px 4px;
  transition: all 150ms ease;
  position: relative;
}

.widget-nav-item:hover {
  color: var(--text-2);
  background: var(--bg-2);
}

.widget-nav-item--active {
  color: var(--brand) !important;
}

.widget-nav-item--active::before {
  content: "";
  position: absolute;
  top: 0;
  left: 20%;
  right: 20%;
  height: 2px;
  background: var(--brand);
  border-radius: 0 0 2px 2px;
}

.widget-nav-label {
  font-size: 10px;
  font-weight: 500;
  text-align: center;
  line-height: 1.2;
  white-space: nowrap;
}

/* ─── Feature Layout (shared) ─────────────────────────────────────────────── */
.feature-layout {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
  padding: 16px;
  gap: 14px;
}

.feature-layout::-webkit-scrollbar {
  width: 3px;
}
.feature-layout::-webkit-scrollbar-thumb {
  background: var(--border);
  border-radius: 3px;
}

.feature-header {
  flex-shrink: 0;
}

.feature-title {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-1);
  letter-spacing: -0.2px;
}

.feature-subtitle {
  font-size: 12px;
  color: var(--text-3);
  margin-top: 3px;
  line-height: 1.5;
}

/* ─── Form elements ───────────────────────────────────────────────────────── */
.feature-form {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.form-label {
  font-size: 12px;
  font-weight: 500;
  color: var(--text-2);
  margin-bottom: -4px;
}

.form-input {
  width: 100%;
  padding: 9px 12px;
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  font-size: 13px;
  color: var(--text-1);
  background: var(--bg-2);
  outline: none;
  transition:
    border-color 120ms ease,
    box-shadow 120ms ease;
}

.form-input:focus {
  border-color: var(--brand);
  box-shadow: 0 0 0 3px rgb(26 158 118 / 0.12);
  background: var(--bg);
}

.form-input::placeholder {
  color: var(--text-3);
}

.form-suggestions {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.suggestion-chip {
  background: var(--brand-light);
  border: 1px solid #b2e8d8;
  color: var(--brand-dark);
  padding: 4px 10px;
  border-radius: var(--radius-full);
  font-size: 11px;
  font-weight: 500;
  transition: all 120ms ease;
}

.suggestion-chip:hover {
  background: #cff0e8;
  border-color: var(--brand);
}

/* ─── Buttons ─────────────────────────────────────────────────────────────── */
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 6px;
  border-radius: var(--radius-md);
  font-size: 13px;
  font-weight: 500;
  border: 1px solid transparent;
  transition: all 120ms ease;
  white-space: nowrap;
  padding: 9px 16px;
}

.btn:disabled {
  cursor: not-allowed;
}

.btn-primary-custom {
  background: var(--brand);
  color: white;
  border-color: var(--brand);
}
.btn-primary-custom:hover:not(:disabled) {
  background: var(--brand-dark);
  border-color: var(--brand-dark);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgb(26 158 118 / 0.3);
}

.btn-secondary {
  background: var(--bg);
  color: var(--text-2);
  border-color: var(--border);
}
.btn-secondary:hover:not(:disabled) {
  background: var(--bg-2);
}

.btn-sm {
  padding: 6px 12px;
  font-size: 12px;
}
.btn-full {
  width: 100%;
}

/* ─── Feature result ──────────────────────────────────────────────────────── */
.feature-result {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.feature-result-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  flex-wrap: wrap;
  gap: 6px;
}

.result-badge {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: 4px 10px;
  border-radius: var(--radius-full);
  font-size: 11px;
  font-weight: 600;
}

.result-badge--green {
  background: #dcfce7;
  color: #15803d;
}

.result-meta {
  font-size: 11px;
  color: var(--text-3);
  font-family: var(--mono);
}

.feature-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
  padding-top: 4px;
}

.feature-loading {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 10px;
  padding: 40px 20px;
}

.loading-spinner {
  width: 28px;
  height: 28px;
  border: 2.5px solid var(--border);
  border-top-color: var(--brand);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

.loading-text {
  font-size: 14px;
  font-weight: 500;
  color: var(--text-1);
}
.loading-sub {
  font-size: 12px;
  color: var(--text-3);
}

.feature-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 24px;
  text-align: center;
  font-size: 13px;
  color: #dc2626;
}

/* ─── Chat Layout ─────────────────────────────────────────────────────────── */
.chat-layout {
  display: flex;
  flex-direction: column;
  height: 100%;
  min-height: 0;
}

.chat-messages {
  flex: 1;
  overflow-y: auto;
  padding: 14px;
  display: flex;
  flex-direction: column;
  gap: 10px;
  min-height: 0;
}

.chat-messages::-webkit-scrollbar {
  width: 3px;
}
.chat-messages::-webkit-scrollbar-thumb {
  background: var(--border);
  border-radius: 3px;
}

/* ─── Chat Empty State ────────────────────────────────────────────────────── */
.chat-empty {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  text-align: center;
  padding: 24px 16px;
  gap: 6px;
}

.chat-empty-avatar {
  width: 52px;
  height: 52px;
  border-radius: var(--radius-lg);
  background: linear-gradient(135deg, var(--brand), var(--brand-dark));
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  margin-bottom: 6px;
}

.chat-empty-greeting {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-1);
}

.chat-empty-sub {
  font-size: 12px;
  color: var(--text-3);
  line-height: 1.5;
  max-width: 210px;
}

.chat-suggestions-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  width: 100%;
  margin-top: 10px;
}

.chat-suggestion-card {
  background: var(--bg-2);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 10px 12px;
  text-align: left;
  transition: all 120ms ease;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.chat-suggestion-card:hover {
  background: var(--brand-light);
  border-color: #b2e8d8;
}

.chat-suggestion-icon {
  width: 24px;
  height: 24px;
  border-radius: 6px;
  background: white;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--brand);
  font-size: 13px;
  border: 1px solid var(--border);
  margin-bottom: 2px;
}

.chat-suggestion-label {
  font-size: 12px;
  font-weight: 500;
  color: var(--text-1);
  line-height: 1.3;
}

/* ─── Chat Messages ───────────────────────────────────────────────────────── */
.chat-message {
  display: flex;
  gap: 7px;
  animation: msg-in 180ms ease;
}

@keyframes msg-in {
  from {
    opacity: 0;
    transform: translateY(6px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.chat-message--user {
  flex-direction: row-reverse;
}

.chat-msg-avatar {
  width: 26px;
  height: 26px;
  min-width: 26px;
  background: linear-gradient(135deg, var(--brand), var(--brand-dark));
  border-radius: 6px;
  display: flex;
  align-items: center;
  justify-content: center;
  color: white;
  margin-top: 2px;
}

.chat-msg-body {
  display: flex;
  flex-direction: column;
  gap: 3px;
  max-width: 76%;
}

.chat-message--user .chat-msg-body {
  align-items: flex-end;
}

.chat-msg-bubble {
  padding: 9px 12px;
  border-radius: var(--radius-lg);
  font-size: 13px;
  line-height: 1.55;
  background: var(--bg-2);
  border: 1px solid var(--border);
  color: var(--text-1);
  word-break: break-word;
}

.chat-message--user .chat-msg-bubble {
  background: var(--brand);
  color: white;
  border-color: var(--brand);
  border-bottom-right-radius: 4px;
}

.chat-message--assistant .chat-msg-bubble {
  border-bottom-left-radius: 4px;
}

.chat-msg-time {
  font-size: 10px;
  color: var(--text-3);
  padding: 0 2px;
}

.chat-error-bar {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  background: #fef2f2;
  border: 1px solid #fecaca;
  border-radius: var(--radius-md);
  font-size: 12px;
  color: #dc2626;
  margin: 0 14px;
}

/* ─── Typing Indicator ────────────────────────────────────────────────────── */
.typing-indicator {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 2px 2px;
}

.typing-dot {
  width: 5px;
  height: 5px;
  background: var(--text-3);
  border-radius: 50%;
  animation: typing-bounce 1.2s ease-in-out infinite;
}

.typing-dot:nth-child(2) {
  animation-delay: 0.2s;
}
.typing-dot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing-bounce {
  0%,
  60%,
  100% {
    transform: translateY(0);
    opacity: 0.5;
  }
  30% {
    transform: translateY(-4px);
    opacity: 1;
  }
}

/* ─── Chat Input ──────────────────────────────────────────────────────────── */
.chat-input-wrap {
  display: flex;
  align-items: flex-end;
  gap: 8px;
  padding: 10px 12px;
  border-top: 1px solid var(--border);
  background: var(--bg);
  flex-shrink: 0;
}

.chat-input-textarea {
  flex: 1;
  resize: none;
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 8px 12px;
  font-size: 13px;
  color: var(--text-1);
  background: var(--bg-2);
  outline: none;
  max-height: 100px;
  overflow-y: auto;
  line-height: 1.5;
  transition:
    border-color 120ms,
    box-shadow 120ms;
}

.chat-input-textarea:focus {
  border-color: var(--brand);
  box-shadow: 0 0 0 3px rgb(26 158 118/0.12);
  background: var(--bg);
}

.chat-input-textarea::placeholder {
  color: var(--text-3);
}

.chat-input-send {
  width: 34px;
  height: 34px;
  border-radius: var(--radius-md);
  border: none;
  background: var(--brand);
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 120ms ease;
  flex-shrink: 0;
}

.chat-input-send:hover:not(:disabled) {
  background: var(--brand-dark);
  transform: translateY(-1px);
}

.chat-input-send:disabled {
  background: var(--border);
  color: var(--text-3);
  cursor: not-allowed;
}

/* ─── Speech to SOAP ──────────────────────────────────────────────────────── */
.sts-layout {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow-y: auto;
  padding: 16px;
  gap: 14px;
}

.sts-progress {
  display: flex;
  justify-content: center;
  align-items: center;
  gap: 20px; /* jarak antar step lebih rapat */
  margin-bottom: 16px;
}

.sts-step {
  flex: none;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 2px;
  position: relative;
}

.sts-step:not(:last-child)::after {
  content: "";
  position: absolute;
  top: 10px;
  left: 50%;
  width: 40px; /* garis lebih pendek */
  height: 1px;
  background: var(--border);
  z-index: 0;
}

.sts-step--done:not(:last-child)::after {
  background: var(--brand);
}

.sts-step-dot {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  background: var(--bg-3);
  border: 1.5px solid var(--border-2);
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: 600;
  color: var(--text-3);
  z-index: 1;
  transition: all 150ms ease;
}

.sts-step--active .sts-step-dot {
  background: var(--brand);
  border-color: var(--brand);
  color: white;
  box-shadow: 0 0 0 3px rgb(26 158 118 / 0.2);
}

.sts-step--done .sts-step-dot {
  background: var(--brand-light);
  border-color: var(--brand);
  color: var(--brand-dark);
}

.sts-step-label {
  font-size: 9px;
  color: var(--text-3);
  font-weight: 500;
  text-align: center;
}

.sts-step--active .sts-step-label {
  color: var(--brand-dark);
  font-weight: 600;
}

.sts-step--done .sts-step-label {
  color: var(--brand);
}

/* Recorder */
.recorder-view {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 30px;
  padding: 20px 16px;
  flex: 1;
}

.recorder-ring {
  width: 88px;
  height: 88px;
  border-radius: 50%;
  border: 2px solid var(--border);
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 0.3s ease;
}

.recorder-ring--active {
  border-color: rgba(15, 110, 86, 0.3);
  box-shadow:
    0 0 0 8px rgba(15, 110, 86, 0.07),
    0 0 0 16px rgba(15, 110, 86, 0.04);
  animation: ring-pulse 1.5s ease-in-out infinite;
}

@keyframes ring-pulse {
  0%,
  100% {
    box-shadow:
      0 0 0 8px rgba(15, 110, 86, 0.07),
      0 0 0 16px rgba(15, 110, 86, 0.04);
  }
  50% {
    box-shadow:
      0 0 0 12px rgba(15, 110, 86, 0.1),
      0 0 0 22px rgba(15, 110, 86, 0.06);
  }
}

.recorder-btn {
  width: 68px;
  height: 68px;
  border-radius: 50%;
  border: none;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: all 150ms ease;
  box-shadow: var(--shadow-md);
}

.recorder-btn--start {
  background: var(--brand);
  color: white;
}
.recorder-btn--start:hover {
  background: var(--brand-dark);
  transform: scale(1.04);
}
.recorder-btn--stop {
  background: #0f6e56;
  color: white;
}
.recorder-btn--stop:hover {
  background: #085041;
}
.recorder-btn:disabled {
  background: var(--bg-3);
  color: var(--text-3);
  cursor: not-allowed;
  transform: none;
  box-shadow: none;
}

.recorder-duration {
  font-size: 26px;
  font-weight: 600;
  font-family: var(--mono);
  color: #0f6e56;
  letter-spacing: 0.05em;
}
.recorder-status-text {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-2);
}
.recorder-status-text--rec {
  color: #0f6e56;
  display: flex;
  align-items: center;
  gap: 6px;
}
.rec-dot {
  width: 7px;
  height: 7px;
  background: #0f6e56;
  border-radius: 50%;
  animation: rec-blink 1s ease-in-out infinite;
}
@keyframes rec-blink {
  0%,
  100% {
    opacity: 1;
  }
  50% {
    opacity: 0.2;
  }
}
.recorder-hint {
  font-size: 11px;
  color: var(--text-3);
  max-width: 200px;
  line-height: 1.5;
  text-align: center;
}
.recorder-processing {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 8px;
}
.recorder-visualizer {
  background: rgba(29, 158, 117, 0.06);
  border-radius: 8px;
}

/* .recorder-duration {
  color: var(--brand); 
}
.recorder-status-text--rec {
  color: var(--brand);
}
.rec-dot {
  background: var(--brand);
} */

/* Transcript */
.transcript-review {
  display: flex;
  flex-direction: column;
  gap: 10px;
  flex: 1;
}
.transcript-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-1);
}
.transcript-sub {
  font-size: 11px;
  color: var(--text-3);
  margin-top: 2px;
}
.transcript-textarea {
  flex: 1;
  min-height: 140px;
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 10px 12px;
  font-size: 12px;
  line-height: 1.6;
  color: var(--text-1);
  background: var(--bg-2);
  outline: none;
  resize: none;
  transition: border-color 120ms;
}
.transcript-textarea:focus {
  border-color: var(--brand);
  box-shadow: 0 0 0 3px rgb(26 158 118/0.12);
  background: var(--bg);
}
.transcript-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
}

/* SOAP Result */

.soap-list {
  margin: 4px 0 8px 0;
  padding-left: 1.2rem;
  line-height: 1.6;
}

.soap-list li + li {
  margin-top: 4px;
}

.soap-plan > div {
  margin-bottom: 8px;
}

.soap-plan strong {
  display: block;
  margin-bottom: 4px;
  color: #444;
}

.soap-table {
  width: 100%;
  border-collapse: collapse;
}

.soap-key {
  font-weight: 600;
  padding-right: 8px;
  vertical-align: top;
}

.soap-value {
  white-space: pre-wrap;
}

.soap-result {
  display: flex;
  flex-direction: column;
  gap: 10px;
}
.soap-result-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.soap-result-ts {
  font-size: 10px;
  color: var(--text-3);
  font-family: var(--mono);
}
.soap-sections {
  display: flex;
  flex-direction: column;
  gap: 7px;
}

.soap-section {
  border-radius: var(--radius-md);
  padding: 10px 12px;
  border-left: 3px solid;
}
.soap-section--blue {
  background: #eff6ff;
  border-left-color: #3b82f6;
}
.soap-section--green {
  background: #f0fdf4;
  border-left-color: #22c55e;
}
.soap-section--orange {
  background: #fff7ed;
  border-left-color: #f97316;
}
.soap-section--purple {
  background: #faf5ff;
  border-left-color: #a855f7;
}

.soap-section-head {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 5px;
}
.soap-section-icon {
  width: 18px;
  height: 18px;
  border-radius: 4px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 10px;
  font-weight: 700;
  font-family: var(--mono);
}
.soap-section--blue .soap-section-icon {
  background: #dbeafe;
  color: #1d4ed8;
}
.soap-section--green .soap-section-icon {
  background: #dcfce7;
  color: #15803d;
}
.soap-section--orange .soap-section-icon {
  background: #ffedd5;
  color: #c2410c;
}
.soap-section--purple .soap-section-icon {
  background: #f3e8ff;
  color: #7e22ce;
}

.soap-section-label {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-2);
}
.soap-section-content {
  font-size: 12px;
  line-height: 1.6;
  color: var(--text-1);
  white-space: pre-line;
}
.soap-actions {
  display: flex;
  gap: 8px;
  justify-content: flex-end;
  padding-top: 2px;
}

/* ─── Clinical Pathway ────────────────────────────────────────────────────── */
.pathway-steps {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.pathway-step {
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  overflow: hidden;
}

.pathway-step-day {
  background: var(--bg-3);
  padding: 7px 12px;
  font-size: 11px;
  font-weight: 600;
  color: var(--text-2);
  border-bottom: 1px solid var(--border);
}

.pathway-step-body {
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.pathway-group {
  display: flex;
  flex-direction: column;
  gap: 3px;
}

.pathway-group-label {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-3);
}

.pathway-group-label--blue {
  color: #1d4ed8;
}
.pathway-group-label--purple {
  color: #7e22ce;
}

.pathway-item {
  font-size: 12px;
  color: var(--text-1);
  line-height: 1.5;
}

/* ─── E-Claim ─────────────────────────────────────────────────────────────── */
.eclaim-status {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 14px;
  border-radius: var(--radius-md);
}

.eclaim-status--eligible {
  background: #f0fdf4;
  border: 1px solid #bbf7d0;
}
.eclaim-status--ineligible {
  background: #fef2f2;
  border: 1px solid #fecaca;
}

.eclaim-status-icon {
  width: 36px;
  height: 36px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.eclaim-status--eligible .eclaim-status-icon {
  background: #22c55e;
  color: white;
}
.eclaim-status--ineligible .eclaim-status-icon {
  background: #dc2626;
  color: white;
}

.eclaim-status-title {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-1);
}
.eclaim-status-sub {
  font-size: 11px;
  color: var(--text-3);
  margin-top: 2px;
  font-family: var(--mono);
}

.eclaim-cost-row {
  display: flex;
  align-items: center;
  background: var(--bg-2);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  overflow: hidden;
}

.eclaim-cost-item {
  flex: 1;
  padding: 10px 14px;
}
.eclaim-cost-divider {
  width: 1px;
  height: 40px;
  background: var(--border);
}
.eclaim-cost-label {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-3);
}
.eclaim-cost-value {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-1);
  margin-top: 2px;
  font-family: var(--mono);
}
.eclaim-cost-value--covered {
  color: #15803d;
}

.eclaim-notes {
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.eclaim-notes-title {
  font-size: 11px;
  font-weight: 600;
  color: var(--text-2);
}
.eclaim-note-item {
  display: flex;
  align-items: flex-start;
  gap: 7px;
}
.eclaim-note-dot {
  width: 5px;
  height: 5px;
  background: var(--brand);
  border-radius: 50%;
  margin-top: 5px;
  flex-shrink: 0;
}
.eclaim-note-item p {
  font-size: 12px;
  color: var(--text-1);
  line-height: 1.5;
}

.eclaim-code {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 12px;
  background: var(--brand-light);
  border-radius: var(--radius-md);
  border: 1px solid #b2e8d8;
}
.eclaim-code-label {
  font-size: 11px;
  font-weight: 500;
  color: var(--brand-dark);
}
.eclaim-code-value {
  font-size: 12px;
  font-weight: 600;
  color: var(--brand-dark);
  font-family: var(--mono);
}

/* ─── SDK FAB + Panel ─────────────────────────────────────────────────────── */
#his-ai-fab {
  position: fixed;
  bottom: 24px;
  right: 24px;
  z-index: 9999;
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 8px;
}

.sdk-fab-tooltip-wrapper {
  position: absolute;
  bottom: 120%; /* muncul di atas tombol */
  left: 50%;
  transform: translateX(-50%) !important;
}

.sdk-fab-tooltip {
  animation: fab-label-bob 2.5s ease-in-out infinite;
  font-family: "DM Sans", system-ui, sans-serif;
  background: var(--text-1);
  color: white;
  padding: 4px 8px;
  border-radius: var(--radius-full);
  font-size: 12px;
  font-weight: 500;
  white-space: nowrap;
  opacity: 0;
  pointer-events: none;
  transition: opacity 0.2s;
}

.sdk-fab-btn:hover .sdk-fab-tooltip {
  opacity: 1;
}

.sdk-fab-label {
  padding: 5px 12px;

  font-size: 12px;

  box-shadow: var(--shadow-md);

  pointer-events: none;
  white-space: nowrap;
}

@keyframes fab-label-bob {
  0%,
  100% {
    transform: translateY(0);
  }
  50% {
    transform: translateY(-3px);
  }
}

.sdk-fab-btn {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  border: none;
  background: linear-gradient(135deg, var(--brand), var(--brand-dark));
  color: white;
  display: flex;
  align-items: center;
  justify-content: center;
  box-shadow:
    0 6px 20px rgb(26 158 118/0.45),
    0 2px 8px rgb(0 0 0/0.12);
  transition: all 200ms cubic-bezier(0.34, 1.56, 0.64, 1);
  position: relative;
  cursor: pointer;
  transition:
    opacity 0.3s ease-in-out,
    transform 0.3s ease-in-out;
}

.sdk-fab-btn:hover .sdk-fab-label {
  opacity: 1;
  transform: translateX(-60%) translateY(-4px); /* sedikit naik saat muncul */
}

.sdk-fab-btn::before {
  content: "";
  position: absolute;
  inset: -4px;
  border-radius: 50%;
  border: 1.5px solid rgba(26, 158, 118, 0.3);
  animation: fab-ring 2s ease-in-out infinite;
}

@keyframes fab-ring {
  0%,
  100% {
    transform: scale(1);
    opacity: 1;
  }
  50% {
    transform: scale(1.08);
    opacity: 0.5;
  }
}

.sdk-fab-btn:hover {
  transform: scale(1.06);
  box-shadow: 0 8px 28px rgb(26 158 118/0.55);
}
.sdk-fab-btn--open {
  background: linear-gradient(135deg, #475569, #1e293b);
}

.sdk-fab-icon-open,
.sdk-fab-icon-close {
  position: absolute;
  transition: all 200ms ease;
}
.sdk-fab-icon-close {
  opacity: 0;
  transform: rotate(-90deg) scale(0.5);
}
.sdk-fab-btn--open .sdk-fab-icon-open {
  opacity: 0;
  transform: rotate(90deg) scale(0.5);
}
.sdk-fab-btn--open .sdk-fab-icon-close {
  opacity: 1;
  transform: rotate(0) scale(1);
}

.sdk-widget-panel {
  position: fixed;
  bottom: 96px;
  right: 24px;
  z-index: 9998;
  transform-origin: bottom right;
  transform: scale(0.88) translateY(16px);
  opacity: 0;
  pointer-events: none;
  transition:
    transform 260ms cubic-bezier(0.34, 1.3, 0.64, 1),
    opacity 200ms ease;
}

.sdk-widget-panel--open {
  transform: scale(1) translateY(0);
  opacity: 1;
  pointer-events: all;
}

/* ─── Dev preview ─────────────────────────────────────────────────────────── */
.dev-preview {
  display: flex;
  align-items: center;
  justify-content: center;
  min-height: 100vh;
  padding: 32px 16px;
}

/* ─── Responsive ──────────────────────────────────────────────────────────── */
@media (max-width: 480px) {
  :root {
    --widget-w: 100vw;
    --widget-h: 100dvh;
  }
  .widget-root {
    border-radius: 0;
  }
  #his-ai-fab {
    bottom: 16px;
    right: 16px;
  }
  .sdk-widget-panel {
    right: 0;
    bottom: 84px;
  }
}

/* ─── Chat input clear button ─────────────────────────────────────────────── */
.chat-input-clear {
  width: 30px;
  height: 30px;
  border: none;
  background: transparent;
  color: var(--text-3);
  border-radius: var(--radius-sm);
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition: all 120ms ease;
  flex-shrink: 0;
}
.chat-input-clear:hover {
  background: var(--bg-3);
  color: var(--color-error, #dc2626);
}

/* ─── Transcript preview (SOAP result) ───────────────────────────────────── */
.soap-transcript-preview {
  background: var(--bg-2);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 10px 13px;
  margin-bottom: 10px;
}
.soap-transcript-label {
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: var(--text-3);
  margin-bottom: 0;
}
.soap-transcript-text {
  font-size: 12px;
  color: var(--text-2);
  line-height: 1.6;
  margin-top: 8px;
}

.soap-table {
  width: 100%;
  border-collapse: collapse;
}
.soap-key {
  font-weight: 600;
  padding-right: 0.5rem;
  vertical-align: top;
}
.soap-value {
  color: #444;
}

.soap-transcript-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  cursor: pointer;
  user-select: none;
}

.accordion-chevron {
  color: var(--text-3);
  transition: transform 200ms ease;
  flex-shrink: 0;
}
.accordion-chevron--open {
  transform: rotate(180deg);
}

.btn-copy {
  font-size: 10px !important;
  background: none;
  border: 1px solid #ccc;
  border-radius: 6px;
  padding: 4px 8px;
  cursor: pointer;
  font-size: 0.85rem;
  transition: background 0.2s;
}

.btn-copy:hover {
  background: #eee;
}

/* ─── Suggestion Panel ────────────────────────────────────────────────────── */
.suggestion-panel {
  border-radius: var(--radius-md);
  border: 1px solid #e2e8f0;
  overflow: hidden;
  background: var(--surface-1, #fff);
  margin-top: 4px;
}

.suggestion-panel-header {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 8px 12px;
  background: #f8fafc;
  border-bottom: 1px solid #e2e8f0;
}

.suggestion-panel-title {
  font-size: 11px;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  color: var(--text-2, #64748b);
  flex: 1;
}

.suggestion-panel-hint {
  font-size: 10px;
  color: var(--text-3, #94a3b8);
}

/* ─── Tabs ───────────────────────────────────────────────────────────────── */
.suggestion-tabs {
  display: flex;
  border-bottom: 1px solid #e2e8f0;
  background: #f8fafc;
}

.suggestion-tab {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 5px;
  padding: 7px 10px;
  font-size: 11px;
  font-weight: 500;
  color: var(--text-3, #94a3b8);
  background: none;
  border: none;
  border-bottom: 2px solid transparent;
  cursor: pointer;
  transition:
    color 0.15s,
    border-color 0.15s;
}

.suggestion-tab:hover {
  color: var(--text-1, #1e293b);
}

.suggestion-tab--active {
  color: #3b82f6;
  border-bottom-color: #3b82f6;
  font-weight: 600;
}

.suggestion-tab-count {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 16px;
  height: 16px;
  padding: 0 4px;
  border-radius: 8px;
  font-size: 9px;
  font-weight: 700;
  background: #e2e8f0;
  color: var(--text-2, #64748b);
}

.suggestion-tab--active .suggestion-tab-count {
  background: #dbeafe;
  color: #1d4ed8;
}

/* ─── List ───────────────────────────────────────────────────────────────── */
.suggestion-list {
  display: flex;
  flex-direction: column;
}

.suggestion-row {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 12px;
  border-bottom: 1px solid #f1f5f9;
  transition: background 0.12s;
}

.suggestion-row:last-child {
  border-bottom: none;
}

.suggestion-row:hover {
  background: #f8fafc;
}

/* Primary diagnosis: faint blue-tinted left border */
.suggestion-row--primary {
  border-left: 3px solid #3b82f6;
}

/* Secondary diagnosis: faint gray left border */
.suggestion-row--secondary {
  border-left: 3px solid #cbd5e1;
}

/* Procedure: faint teal left border */
.suggestion-row--procedure {
  border-left: 3px solid #14b8a6;
}

.suggestion-row-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.suggestion-row-top {
  display: flex;
  align-items: center;
  gap: 5px;
}

.suggestion-icd {
  font-size: 10px;
  font-weight: 700;
  font-family: var(--mono, monospace);
  color: var(--text-2, #64748b);
}

.suggestion-name {
  font-size: 11px;
  color: var(--text-1, #1e293b);
  line-height: 1.4;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* ─── Badges ─────────────────────────────────────────────────────────────── */
.suggestion-badge {
  display: inline-flex;
  align-items: center;
  padding: 1px 5px;
  border-radius: 4px;
  font-size: 9px;
  font-weight: 600;
  text-transform: uppercase;
  letter-spacing: 0.04em;
}

.suggestion-badge--primary {
  background: #dbeafe;
  color: #1d4ed8;
}

.suggestion-badge--secondary {
  background: #f1f5f9;
  color: #64748b;
}

/* ─── Save button ─────────────────────────────────────────────────────────── */
.suggestion-save-btn {
  flex-shrink: 0;
  width: 26px;
  height: 26px;
  border-radius: 6px;
  border: 1.5px solid #cbd5e1;
  background: #fff;
  color: #94a3b8;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  transition:
    background 0.15s,
    border-color 0.15s,
    color 0.15s,
    transform 0.1s;
}

.suggestion-save-btn:hover {
  background: #eff6ff;
  border-color: #3b82f6;
  color: #3b82f6;
  transform: scale(1.08);
}

.suggestion-save-btn--saved {
  background: #22c55e !important;
  border-color: #22c55e !important;
  color: #fff !important;
  transform: scale(1.08);
}
/* Markdown Body Styles for AI Assistant Chat */
.markdown-body {
  font-family: inherit;
  font-size: inherit;
  line-height: 1.5;
  color: inherit;
}
.markdown-body p {
  margin-top: 0;
  margin-bottom: 0.5rem;
}
.markdown-body p:last-child {
  margin-bottom: 0;
}
.markdown-body strong {
  font-weight: 600;
  color: var(--his-color-neutral-900);
}
.markdown-body ul,
.markdown-body ol {
  margin-top: 0.25rem;
  margin-bottom: 0.5rem;
  padding-left: 1.2rem;
}
.markdown-body li {
  margin-bottom: 0.25rem;
}
.markdown-body h1,
.markdown-body h2,
.markdown-body h3,
.markdown-body h4 {
  margin-top: 0.75rem;
  margin-bottom: 0.5rem;
  font-weight: 600;
}
`

let _injected = false

export function injectStyles(): void {
  if (_injected) return
  if (typeof document === 'undefined') return

  // Cek apakah sudah ada (support multiple init() call)
  if (document.getElementById('his-ai-widget-css')) {
    _injected = true
    return
  }

  const style = document.createElement('style')
  style.id = 'his-ai-widget-css'
  style.textContent = CSS
  document.head.appendChild(style)
  _injected = true
}
